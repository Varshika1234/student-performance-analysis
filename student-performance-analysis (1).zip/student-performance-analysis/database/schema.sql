CREATE DATABASE IF NOT EXISTS student_performance
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE student_performance;

CREATE TABLE IF NOT EXISTS students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    roll_no VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    section VARCHAR(30) NOT NULL
);

CREATE TABLE IF NOT EXISTS subjects (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_name VARCHAR(100) NOT NULL UNIQUE,
    max_marks DECIMAL(7,2) NOT NULL,
    pass_marks DECIMAL(7,2) NOT NULL,
    CHECK (max_marks > 0),
    CHECK (pass_marks >= 0 AND pass_marks <= max_marks)
);

CREATE TABLE IF NOT EXISTS marks (
    mark_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    assessment VARCHAR(100) NOT NULL,
    marks_obtained DECIMAL(7,2) NOT NULL,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
    UNIQUE KEY unique_student_subject_assessment (student_id, subject_id, assessment),
    CHECK (marks_obtained >= 0)
);

-- Optional sample data. Run once after the tables are created.
INSERT IGNORE INTO students (roll_no, name, section) VALUES
('101', 'Aarav Sharma', 'A'), ('102', 'Diya Reddy', 'A'),
('103', 'Kabir Rao', 'B'), ('104', 'Meera Das', 'B');

INSERT IGNORE INTO subjects (subject_name, max_marks, pass_marks) VALUES
('Mathematics', 100, 35), ('Computer Science', 100, 35),
('English', 100, 35), ('Physics', 100, 35);

INSERT IGNORE INTO marks (student_id, subject_id, assessment, marks_obtained)
SELECT st.student_id, su.subject_id, 'Midterm',
CASE
 WHEN st.roll_no='101' AND su.subject_name='Mathematics' THEN 92
 WHEN st.roll_no='101' AND su.subject_name='Computer Science' THEN 95
 WHEN st.roll_no='101' AND su.subject_name='English' THEN 84
 WHEN st.roll_no='101' AND su.subject_name='Physics' THEN 88
 WHEN st.roll_no='102' AND su.subject_name='Mathematics' THEN 78
 WHEN st.roll_no='102' AND su.subject_name='Computer Science' THEN 86
 WHEN st.roll_no='102' AND su.subject_name='English' THEN 91
 WHEN st.roll_no='102' AND su.subject_name='Physics' THEN 73
 WHEN st.roll_no='103' AND su.subject_name='Mathematics' THEN 55
 WHEN st.roll_no='103' AND su.subject_name='Computer Science' THEN 62
 WHEN st.roll_no='103' AND su.subject_name='English' THEN 48
 WHEN st.roll_no='103' AND su.subject_name='Physics' THEN 58
 WHEN st.roll_no='104' AND su.subject_name='Mathematics' THEN 28
 WHEN st.roll_no='104' AND su.subject_name='Computer Science' THEN 44
 WHEN st.roll_no='104' AND su.subject_name='English' THEN 32
 ELSE 39 END
FROM students st CROSS JOIN subjects su;
