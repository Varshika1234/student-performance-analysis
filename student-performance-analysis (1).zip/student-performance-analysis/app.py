import io
import os
from functools import wraps

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from flask import Flask, Response, flash, redirect, render_template, request, url_for
from dotenv import load_dotenv

from db import get_connection, init_db

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "change-this-development-key")


def query_all(sql, params=()):
    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(sql, params)
        return cur.fetchall()
    finally:
        cur.close()
        conn.close()


def execute(sql, params=()):
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        conn.commit()
        return cur.lastrowid
    finally:
        cur.close()
        conn.close()


def get_subject(subject_id):
    rows = query_all("SELECT * FROM subjects WHERE subject_id=%s", (subject_id,))
    return rows[0] if rows else None


@app.route("/")
def dashboard():
    students = query_all("SELECT COUNT(*) AS n FROM students")[0]["n"]
    subjects = query_all("SELECT COUNT(*) AS n FROM subjects")[0]["n"]
    marks_count = query_all("SELECT COUNT(*) AS n FROM marks")[0]["n"]
    summary = query_all("""
        SELECT COUNT(*) AS total,
               SUM(CASE WHEN m.marks_obtained >= s.pass_marks THEN 1 ELSE 0 END) AS passed
        FROM marks m JOIN subjects s ON s.subject_id=m.subject_id
    """)[0]
    pass_rate = round(100 * (summary["passed"] or 0) / summary["total"], 1) if summary["total"] else 0
    return render_template("dashboard.html", students=students, subjects=subjects,
                           marks_count=marks_count, pass_rate=pass_rate)


@app.route("/students")
def students():
    rows = query_all("SELECT * FROM students ORDER BY section, roll_no")
    return render_template("students.html", students=rows)


@app.route("/students/add", methods=["GET", "POST"])
def add_student():
    if request.method == "POST":
        roll = request.form.get("roll_no", "").strip()
        name = request.form.get("name", "").strip()
        section = request.form.get("section", "").strip()
        if not roll or not name or not section:
            flash("Please fill in every field.", "error")
        else:
            try:
                execute("INSERT INTO students (roll_no, name, section) VALUES (%s,%s,%s)",
                        (roll, name, section))
                flash("Student added successfully.", "success")
                return redirect(url_for("students"))
            except Exception as exc:
                flash("Could not add student. Check that the roll number is unique.")
    return render_template("student_form.html", student=None)


@app.route("/students/<int:student_id>/edit", methods=["GET", "POST"])
def edit_student(student_id):
    rows = query_all("SELECT * FROM students WHERE student_id=%s", (student_id,))
    if not rows:
        flash("Student not found.", "error")
        return redirect(url_for("students"))
    student = rows[0]
    if request.method == "POST":
        roll = request.form.get("roll_no", "").strip()
        name = request.form.get("name", "").strip()
        section = request.form.get("section", "").strip()
        if not roll or not name or not section:
            flash("Please fill in every field.", "error")
        else:
            try:
                execute("UPDATE students SET roll_no=%s,name=%s,section=%s WHERE student_id=%s",
                        (roll, name, section, student_id))
                flash("Student updated.", "success")
                return redirect(url_for("students"))
            except Exception:
                flash("Update failed. Roll numbers must be unique.", "error")
    return render_template("student_form.html", student=student)


@app.route("/students/<int:student_id>/delete", methods=["POST"])
def delete_student(student_id):
    execute("DELETE FROM students WHERE student_id=%s", (student_id,))
    flash("Student and associated marks deleted.", "success")
    return redirect(url_for("students"))


@app.route("/subjects")
def subjects():
    return render_template("subjects.html",
                           subjects=query_all("SELECT * FROM subjects ORDER BY subject_name"))


@app.route("/subjects/add", methods=["GET", "POST"])
def add_subject():
    if request.method == "POST":
        name = request.form.get("subject_name", "").strip()
        try:
            maximum = int(request.form.get("max_marks", ""))
            passing = int(request.form.get("pass_marks", ""))
            if not name or maximum <= 0 or passing < 0 or passing > maximum:
                raise ValueError
            execute("INSERT INTO subjects (subject_name,max_marks,pass_marks) VALUES (%s,%s,%s)",
                    (name, maximum, passing))
            flash("Subject added.", "success")
            return redirect(url_for("subjects"))
        except ValueError:
            flash("Enter a subject name, max marks above 0, and pass marks from 0 to max marks.", "error")
        except Exception:
            flash("Could not add subject. The subject name may already exist.", "error")
    return render_template("subject_form.html")


@app.route("/subjects/<int:subject_id>/delete", methods=["POST"])
def delete_subject(subject_id):
    execute("DELETE FROM subjects WHERE subject_id=%s", (subject_id,))
    flash("Subject and associated marks deleted.", "success")
    return redirect(url_for("subjects"))


@app.route("/marks")
def marks():
    rows = query_all("""
        SELECT m.mark_id, m.assessment, m.marks_obtained, st.student_id, st.roll_no,
               st.name, st.section, su.subject_name, su.max_marks, su.pass_marks
        FROM marks m JOIN students st ON st.student_id=m.student_id
        JOIN subjects su ON su.subject_id=m.subject_id
        ORDER BY st.section, st.roll_no, su.subject_name, m.assessment
    """)
    return render_template("marks.html", marks=rows)


@app.route("/marks/add", methods=["GET", "POST"])
def add_mark():
    student_rows = query_all("SELECT * FROM students ORDER BY section, roll_no")
    subject_rows = query_all("SELECT * FROM subjects ORDER BY subject_name")
    if request.method == "POST":
        try:
            student_id = int(request.form["student_id"])
            subject_id = int(request.form["subject_id"])
            assessment = request.form.get("assessment", "").strip()
            marks_obtained = float(request.form["marks_obtained"])
            subject = get_subject(subject_id)
            if not assessment or not subject or not any(s["student_id"] == student_id for s in student_rows):
                raise ValueError
            if not np.isfinite(marks_obtained) or marks_obtained < 0 or marks_obtained > subject["max_marks"]:
                flash(f"Marks must be between 0 and {subject['max_marks']}.", "error")
            else:
                execute("""INSERT INTO marks (student_id,subject_id,assessment,marks_obtained)
                           VALUES (%s,%s,%s,%s)""",
                        (student_id, subject_id, assessment, marks_obtained))
                flash("Marks saved.", "success")
                return redirect(url_for("marks"))
        except (ValueError, KeyError):
            flash("Please enter valid student, subject, assessment and marks.", "error")
        except Exception:
            flash("Could not save marks. Please check the entered data.", "error")
    return render_template("mark_form.html", students=student_rows, subjects=subject_rows)


@app.route("/marks/<int:mark_id>/edit", methods=["GET", "POST"])
def edit_mark(mark_id):
    rows = query_all("SELECT * FROM marks WHERE mark_id=%s", (mark_id,))
    if not rows:
        flash("Mark record not found.", "error")
        return redirect(url_for("marks"))
    mark = rows[0]
    student_rows = query_all("SELECT * FROM students ORDER BY section, roll_no")
    subject_rows = query_all("SELECT * FROM subjects ORDER BY subject_name")
    if request.method == "POST":
        try:
            student_id = int(request.form["student_id"])
            subject_id = int(request.form["subject_id"])
            assessment = request.form.get("assessment", "").strip()
            value = float(request.form["marks_obtained"])
            subject = get_subject(subject_id)
            if not assessment or not subject or value < 0 or value > subject["max_marks"]:
                raise ValueError
            execute("""UPDATE marks SET student_id=%s,subject_id=%s,assessment=%s,marks_obtained=%s
                       WHERE mark_id=%s""", (student_id, subject_id, assessment, value, mark_id))
            flash("Marks updated.", "success")
            return redirect(url_for("marks"))
        except (ValueError, KeyError):
            flash("Invalid values. Marks must be between zero and the subject maximum.", "error")
        except Exception:
            flash("Could not update marks.", "error")
    return render_template("mark_form.html", students=student_rows, subjects=subject_rows, mark=mark)


@app.route("/marks/<int:mark_id>/delete", methods=["POST"])
def delete_mark(mark_id):
    execute("DELETE FROM marks WHERE mark_id=%s", (mark_id,))
    flash("Mark record deleted.", "success")
    return redirect(url_for("marks"))


@app.route("/reports")
def reports():
    threshold = request.args.get("threshold", "40")
    try:
        threshold = float(threshold)
        if not 0 <= threshold <= 100:
            raise ValueError
    except ValueError:
        threshold = 40.0
        flash("Threshold must be between 0 and 100. Showing 40%.", "error")

    rows = query_all("""
        SELECT st.student_id, st.roll_no, st.name, st.section, su.subject_name,
               su.max_marks, su.pass_marks, m.assessment, m.marks_obtained
        FROM marks m JOIN students st ON st.student_id=m.student_id
        JOIN subjects su ON su.subject_id=m.subject_id
    """)
    df = pd.DataFrame(rows)
    subject_summary, section_summary, low_performers, toppers = [], [], [], []
    if not df.empty:
        df["percentage"] = df["marks_obtained"] / df["max_marks"] * 100
        df["passed"] = df["marks_obtained"] >= df["pass_marks"]
        subject_summary = (df.groupby("subject_name")
                           .agg(average_percentage=("percentage", "mean"),
                                pass_percentage=("passed", lambda x: x.mean() * 100),
                                records=("passed", "size")).reset_index()
                           .round(1).to_dict("records"))
        section_summary = (df.groupby("section")
                           .agg(average_percentage=("percentage", "mean"),
                                pass_percentage=("passed", lambda x: x.mean() * 100),
                                records=("passed", "size")).reset_index()
                           .round(1).to_dict("records"))
        student_summary = (df.groupby(["student_id", "roll_no", "name", "section"])
                           .agg(average_percentage=("percentage", "mean"),
                                assessments=("percentage", "size")).reset_index())
        student_summary["average_percentage"] = student_summary["average_percentage"].round(1)
        toppers = student_summary.sort_values(
            ["average_percentage", "name"], ascending=[False, True]).head(10).to_dict("records")
        low_performers = student_summary[student_summary["average_percentage"] < threshold].sort_values(
            "average_percentage").to_dict("records")
    return render_template("reports.html", subject_summary=subject_summary,
                           section_summary=section_summary, low_performers=low_performers,
                           toppers=toppers, threshold=threshold, has_data=not df.empty)


@app.route("/reports/subject-chart.png")
def subject_chart():
    rows = query_all("""
        SELECT su.subject_name, AVG(m.marks_obtained / su.max_marks * 100) AS average_percentage
        FROM marks m JOIN subjects su ON su.subject_id=m.subject_id
        GROUP BY su.subject_id, su.subject_name ORDER BY su.subject_name
    """)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    if rows:
        df = pd.DataFrame(rows)
        ax.bar(df["subject_name"], df["average_percentage"])
        ax.set_ylim(0, 100)
        ax.set_ylabel("Average percentage")
        ax.set_title("Subject-wise Average Performance")
        ax.tick_params(axis="x", rotation=25)
    else:
        ax.text(.5, .5, "No marks available yet", ha="center", va="center")
        ax.set_axis_off()
    fig.tight_layout()
    image = io.BytesIO()
    fig.savefig(image, format="png", dpi=140)
    plt.close(fig)
    image.seek(0)
    return Response(image.getvalue(), mimetype="image/png")


@app.route("/reports/pass-chart.png")
def pass_chart():
    rows = query_all("""
        SELECT su.subject_name,
               AVG(CASE WHEN m.marks_obtained >= su.pass_marks THEN 100.0 ELSE 0.0 END) AS pass_percentage
        FROM marks m JOIN subjects su ON su.subject_id=m.subject_id
        GROUP BY su.subject_id, su.subject_name ORDER BY su.subject_name
    """)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    if rows:
        df = pd.DataFrame(rows)
        ax.bar(df["subject_name"], df["pass_percentage"])
        ax.set_ylim(0, 100)
        ax.set_ylabel("Pass percentage")
        ax.set_title("Subject-wise Pass Percentage")
        ax.tick_params(axis="x", rotation=25)
    else:
        ax.text(.5, .5, "No marks available yet", ha="center", va="center")
        ax.set_axis_off()
    fig.tight_layout()
    image = io.BytesIO()
    fig.savefig(image, format="png", dpi=140)
    plt.close(fig)
    image.seek(0)
    return Response(image.getvalue(), mimetype="image/png")


@app.cli.command("init-db")
def init_db_command():
    init_db()
    print("Database tables created successfully.")


if __name__ == "__main__":
    app.run(debug=True)
