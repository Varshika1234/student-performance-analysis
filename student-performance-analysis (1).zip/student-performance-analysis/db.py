import os
import mysql.connector
from dotenv import load_dotenv

load_dotenv()


def get_connection():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "student_performance"),
    )


def init_db():
    # Create the database separately using database/schema.sql before running this command.
    statements = [
        """CREATE TABLE IF NOT EXISTS students (
            student_id INT AUTO_INCREMENT PRIMARY KEY,
            roll_no VARCHAR(30) NOT NULL UNIQUE,
            name VARCHAR(100) NOT NULL,
            section VARCHAR(30) NOT NULL
        )""",
        """CREATE TABLE IF NOT EXISTS subjects (
            subject_id INT AUTO_INCREMENT PRIMARY KEY,
            subject_name VARCHAR(100) NOT NULL UNIQUE,
            max_marks DECIMAL(7,2) NOT NULL,
            pass_marks DECIMAL(7,2) NOT NULL,
            CHECK (max_marks > 0),
            CHECK (pass_marks >= 0 AND pass_marks <= max_marks)
        )""",
        """CREATE TABLE IF NOT EXISTS marks (
            mark_id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT NOT NULL,
            subject_id INT NOT NULL,
            assessment VARCHAR(100) NOT NULL,
            marks_obtained DECIMAL(7,2) NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
            UNIQUE KEY unique_student_subject_assessment (student_id, subject_id, assessment),
            CHECK (marks_obtained >= 0)
        )"""
    ]
    conn = get_connection()
    try:
        cur = conn.cursor()
        for statement in statements:
            cur.execute(statement)
        conn.commit()
    finally:
        cur.close()
        conn.close()
