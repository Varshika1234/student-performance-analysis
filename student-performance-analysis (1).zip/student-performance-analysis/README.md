# Student Performance Analysis System

A beginner-friendly Flask + MySQL project to manage students, subjects, assessment marks, and view performance reports and charts.

## Features

- Student CRUD: add, list, edit, delete
- Subject management and pass/max marks
- Add, edit, delete marks with range validation
- Dashboard counts and overall pass rate
- Subject and section averages/pass rates
- Top 10 students and students below a configurable average-percentage threshold
- Matplotlib charts based on saved MySQL data

## Tech stack

Python, Flask, MySQL, Pandas, NumPy, Matplotlib, HTML/CSS.

## Rules used

- A mark is valid when `0 <= marks_obtained <= subject.max_marks`.
- An assessment is passed when `marks_obtained >= subject.pass_marks`.
- Percentage for each mark record = `marks_obtained / max_marks * 100`.
- Student topper ranking uses the mean of all recorded assessment percentages for that student.
- The low-performing list uses the same mean and a threshold entered on the Reports page (default 40%).
- Subject/section summaries count each recorded assessment row. If a student has multiple assessments, each record contributes separately.

## Setup (Windows PowerShell)

### 1. Install prerequisites

Install Python 3.10+ and MySQL Server. Make sure the MySQL service is running.

### 2. Create and activate a virtual environment

```powershell
cd student-performance-analysis
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that terminal, then activate again.

### 3. Install Python packages

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Configure environment

Copy `.env.example` to `.env`, then edit `.env` and enter your actual MySQL username/password and a random Flask secret key. Do not commit `.env`.

### 5. Create database and sample data

Open MySQL Workbench or the MySQL command line and execute the full `database/schema.sql` file. It creates the database, tables, and sample records.

Command-line alternative (enter your own MySQL credentials):

```powershell
mysql -u root -p < database/schema.sql
```

If the `mysql` command is not on PATH, run the SQL file in MySQL Workbench instead.

### 6. Start the application

```powershell
python app.py
```

Open `http://127.0.0.1:5000` in your browser. Stop the development server with `Ctrl+C`.

For table creation without sample data, create the database first, then run:

```powershell
flask --app app init-db
```

## Main pages

- `/` dashboard
- `/students` students
- `/subjects` subjects
- `/marks` marks
- `/reports` analytics and charts

## Push to GitHub

1. Create a new empty repository on GitHub, for example `student-performance-analysis`. Do not add a README/license there if you already have these files locally.
2. From the project directory, run:

```bash
git init
git add .
git status
git commit -m "Initial commit: student performance analysis system"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/student-performance-analysis.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. GitHub may open a browser sign-in or ask you to authenticate. Do not put a password or token into source code. If Git says `remote origin already exists`, use `git remote set-url origin https://github.com/YOUR-USERNAME/student-performance-analysis.git`.

## Troubleshooting

- **Access denied for MySQL**: verify `DB_USER` and `DB_PASSWORD` in `.env`.
- **Unknown database**: execute `database/schema.sql` first.
- **Module not found**: activate `.venv` and run `pip install -r requirements.txt`.
- **Port 5000 busy**: stop the other app or change the port in the final `app.run(...)` line.
- **Duplicate assessment**: each student + subject + assessment combination must be unique.
- **Charts are empty**: add marks first; charts read directly from the database.

## Security note

This starter project is for local learning. Before public deployment, disable Flask debug mode, use a strong secret key, add authentication/authorization, CSRF protection, and production server configuration. Only use sample or institution-approved student data.
