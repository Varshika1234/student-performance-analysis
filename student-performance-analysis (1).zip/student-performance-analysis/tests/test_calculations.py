import unittest


def percentage(marks, maximum):
    if maximum <= 0 or marks < 0 or marks > maximum:
        raise ValueError("Invalid marks")
    return marks / maximum * 100


def passed(marks, pass_marks):
    return marks >= pass_marks


class CalculationTests(unittest.TestCase):
    def test_percentage(self):
        self.assertEqual(percentage(45, 50), 90)

    def test_rejects_marks_above_max(self):
        with self.assertRaises(ValueError):
            percentage(101, 100)

    def test_rejects_negative_marks(self):
        with self.assertRaises(ValueError):
            percentage(-1, 100)

    def test_pass_boundary(self):
        self.assertTrue(passed(35, 35))
        self.assertFalse(passed(34, 35))


if __name__ == "__main__":
    unittest.main()
